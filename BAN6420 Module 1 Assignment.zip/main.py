import random

# Step 1: Create a list of workers dynamically
workers = []
for _ in range(400):
    worker = {
        'name': f'worker{_}',
        'gender': random.choice(['Male', 'Female']),
        'salary': random.uniform(5000, 30000)
    }
    workers.append(worker)

# Step 2: Implement a for loop to generate payment slips
for worker in workers:
    try:
        # Step 4: Implement conditional statements
        if 10000 < worker['salary'] < 20000:
            worker['level'] = 'A1'
        elif 7500 < worker['salary'] < 30000 and worker['gender'] == 'Female':
            worker['level'] = 'A5-F'
        else:
            worker['level'] = 'unknown'

        # Step 3: Print payment slips
        print(f"{worker['name']} - Salary: ${worker['salary']:.2f}, Level: {worker['level']}")

    except Exception as e:
        # Step 5: Add exception handling
        print(f"Error processing {worker['name']}: {e}")

