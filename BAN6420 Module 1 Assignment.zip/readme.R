# Step 1: Create a list of workers dynamically
workers <- list()
for (i in 1:400) {
  worker <- list(
    name = paste0("worker", i),
    gender = sample(c("Male", "Female"), 1),
    salary = runif(1, 5000, 30000)
  )
  workers <- c(workers, worker)
}

# Step 2: Implement a for loop to generate payment slips
for (worker in workers) {
  # Step 4: Implement conditional statements
  if (10000 < worker$salary & worker$salary < 20000) {
    worker$level <- "A1"
  } else if (7500 < worker$salary & worker$salary < 30000 & worker$gender == "Female") {
    worker$level <- "A5-F"
  } else {
    worker$level <- "unknown"
  }
  
  # Step 3: Print payment slips
  cat(paste0(worker$name, " - Salary: $", sprintf("%.2f", worker$salary), ", Level: ", worker$level, "\n"))
}
